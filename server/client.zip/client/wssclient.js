var client, incoming_messages, outgoing_messages;
var file_image = false;

// if (localStorage.getItem('mail').value != null) {
//     connect(localStorage.getItem('name'), localStorage.getItem('mail'), localStorage.getItem('desig'));
// }


function connect(name, email, dept, pid = "1") {
    // localStorage.setItem('mail', email);
    // localStorage.setItem('name', name);
    switchVisible();
    console.log('called', name, email);
    client = new WsClient({ url: `ws:localhost?name=${name}&email=${email}&dept=${dept}&pid=${pid}` });
    client.onMessage = function (msg) {
        var data = JSON.parse(msg.data);
        date = new Date();
        if (data.name == undefined) {
            if (data.message != '') {
                incoming_messages += incoming_messages + "&&" + data.message;
                // localStorage.setItem('incoming', incoming_messages);
                document.getElementsByClassName('body')[0].innerHTML += `<div class="incoming">
        <div class="bubble">
        <p>${data.message}</p>
        </div>
        <span class="time_date">${date.toLocaleString('en-GB')}</span>`
            }
            // document.getElementsByClassName('msg')[0].disabled = true;
            // document.getElementById('btn_sendMessage').disabled = true;
            // document.getElementById('btn_Attachment').disabled = true;
        }
        else {
            if (data.message != '') {
                incoming_messages += incoming_messages + "&&" + data.message;
                // localStorage.setItem('incoming', incoming_messages);
                document.getElementsByClassName('body')[0].innerHTML += `<div class="incoming">
        <div class="bubble">
        <p>${data.message}</p>
        </div>
        <span class="time_date">${date.toLocaleString('en-GB')}</span>`
            }
            document.getElementsByClassName('msg')[0].disabled = false;
            document.getElementById('btn_sendMessage').disabled = false;
            document.getElementById('btn_Attachment').disabled = false;
        }
    }
}

class WsClient {
    constructor({ url }) {
        this.webSocket = new WebSocket(url);
        this.webSocket.onmessage = this._onMessage.bind(this);
        console.log(`Client Created`);
    }

    _onMessage(message) {
        if (this.onMessage) {
            this.onMessage(message);
        }
    }
    send(message) {
        this.webSocket.send(message);
    }
}


function openChat() {
    document.getElementById("chatBox").style.display = "block";
    document.getElementById("closeChat").style.display = "block";
    document.getElementById("openChat").style.display = "none";
}
function closeChat() {
    document.getElementById("closeChat").style.display = "none";
    document.getElementById("openChat").style.display = "block";
    document.getElementById("chatBox").style.display = "none";
}


function addmessage() {
    if (file_image) {
        var file = document.getElementById('filename').files[0];
        var reader = new FileReader();
        var rawData = new ArrayBuffer();
        reader.loadend = function () {
        }
        reader.onload = function (e) {
            rawData = e.target.result;
            client.send(rawData);
            alert("the File has been transferred.")
        }
        reader.readAsArrayBuffer(file);
        date = new Date();
        var message = document.getElementsByClassName("msg")[0].value;
        document.getElementsByClassName('body')[0].innerHTML += `<div class="outgoing">
        <div class="bubble">
        <a>${message}</a>
        </div>
        <span class="time_date">${date.toLocaleString('en-GB')}</span>`
         document.getElementsByClassName("msg")[0].value = '';
    }
    else {
        var message = document.getElementsByClassName("msg")[0].value;
        client.send(message);
        if (message != '') {
            console.log(message);
            outgoing_messages += outgoing_messages + "&&" + message;
            // localStorage.setItem('outgoing', outgoing_messages);
            date = new Date();
            document.getElementsByClassName('body')[0].innerHTML += `<div class="outgoing">
        <div class="bubble">
        <p>${message}</p>
        </div>
        <span class="time_date">${date.toLocaleString('en-GB')}</span>`
            document.getElementsByClassName("msg")[0].value = '';
        }
        else {
            alert('type a message');
        }
    }
}

function switchVisible() {
    if (document.getElementsByClassName('info')[0]) {

        if (document.getElementsByClassName('info')[0].style.display == 'none') {
            document.getElementsByClassName('info')[0].style.display = 'block';
            document.getElementsByClassName('body')[0].style.display = 'none';
            document.getElementsByClassName('foot')[0].style.display = 'none';

        }
        else {
            document.getElementsByClassName('info')[0].style.display = 'none';
            document.getElementsByClassName('body')[0].style.display = 'block';
            document.getElementsByClassName('foot')[0].style.display = 'flex';
        }
    }
}

function attach() {
    var fileSelector = document.createElement('input');
    fileSelector.setAttribute('id', 'attached_file');
    fileSelector.setAttribute('type', 'file');
    fileSelector.setAttribute('accept', '.jpg,.jpeg,.png')
    fileSelector.click();
}





